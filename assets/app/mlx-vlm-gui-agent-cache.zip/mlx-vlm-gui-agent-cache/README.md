# mlx-vlm 前缀缓存补丁（GUI Agent 负载）

给 `mlx-vlm 0.6.8` 打的一组补丁，让**多轮 GUI Agent** 这类「历史只追加、截图逐步变多」的负载能真正命中前缀缓存与视觉特征缓存。

原版在这种负载下几乎不命中缓存，每一步都要把整个 prompt 重新 prefill、把所有截图重新过一遍视觉编码器。

## 实测收益

在 Apple Silicon 上用真实 agent 轨迹（Qwen3.5 系列 9B，6bit 量化，720p 截图）测得：

| 指标 | 提升 |
|---|---|
| prefill | 约 3.0x |
| 端到端单步 | 约 2.0x |
| 其中逐图视觉缓存贡献 | 约 1.5x |

前缀复用率：不触发历史折叠的步骤 100%，折叠那一步会掉到接近 0，**但下一步立刻恢复**。

正确性：同一条真实轨迹在开关前后输出逐字相同。

这组数字与硬件、量化档位、截图分辨率都强相关，换环境后请以自己实测为准。

## 适用前提

三条都满足才会有上面的收益，缺一条基本没有效果：

1. **模型架构是 `qwen3_5`**。`models/qwen3_5/` 下的 mRoPE 保位和逐图视觉缓存是该架构专属的，换成别的架构（Gemma、Pixtral 等）这两项不生效。
2. **负载是追加式多轮对话**。单轮问答、每次重写历史的场景没有差别。
3. **客户端要把截图丢弃改成批量（锯齿式）**。如果每步都丢弃最老的一张截图，那条历史消息的内容就变了，前缀每步都断——这时服务端再怎么优化也无法命中。攒够若干张一次性丢弃，中间几步才是纯追加的。

## 安装

```bash
pip install mlx-vlm==0.6.8
./apply.sh                                  # 打到当前 python3 环境
PYTHON=/path/to/venv/bin/python ./apply.sh  # 或指定解释器
```

脚本会自动定位 `site-packages`、校验版本、先备份再试运行，任一步失败都不会留下改了一半的代码。重复执行会被识别并跳过。

## 推荐配置

### 服务端环境变量

补丁的新特性**默认全部关闭**，装上不配环境变量等于原版：

```bash
export APC_ENABLED=1
export APC_GROWING_IMAGES=1               # 图片逐步增长时复用前缀
export MLX_INLINE_IMAGE_POSITIONS=1       # 图片 token 按消息就位（前提）
export MLX_VLM_PER_IMAGE_VISION_CACHE=1   # 逐图视觉特征缓存
export MLX_VLM_VISION_CACHE_SIZE=20       # 要 ≥ prompt 里的峰值图片数
export APC_EXACT_CACHE_ENTRIES=8
export APC_EXACT_PREFIX_GUARD_TOKENS=64
```

`MLX_INLINE_IMAGE_POSITIONS` 是整套方案的前提。原版会把所有消息里的图片占位符收集起来、全部塞进最后一条 user 消息，导致每加一张新截图，整块占位符就整体后移，prompt 从第一条 user 消息起就对不上了。打开后图片 token 留在各自的消息里，历史才是真正的追加。

`MLX_VLM_VISION_CACHE_SIZE` 要留够：它是逐图特征缓存能装的图片张数，小于峰值图片数会导致老图被挤出、下一步重新编码。

### 客户端（agent）

这几项和服务端同等重要，配错了服务端优化会全部落空。

| 项 | 推荐值 | 原因 |
|---|---|---|
| 截图分辨率 | 720p | 720p 约 1200 token/图，1920 约 2130 token/图。prompt 直接差一倍，而这部分开销缓存救不了 |
| 截图丢弃方式 | 批量（锯齿式） | 每步丢一张会改写历史消息，前缀每步都断 |
| 保留的截图数（谷） | 4 | 与下一项共同决定峰值 |
| 一次丢弃张数（齿宽） | 4 | 峰值 = 4 + 4 − 1 = 7 张，4 步里有 3 步是纯追加、能命中缓存 |
| 历史思考步数上限 | 不要设 | 一旦设了，旧的 assistant 消息会被回头改写，前缀同样会断 |

峰值图片数（这里是 7）要同时满足两处约束：小于等于 `MLX_VLM_VISION_CACHE_SIZE`；如果前面还挂着 vLLM，也要小于等于它的 `--limit-mm-per-prompt image=N`，否则请求会被直接拒掉。

**不要让别的请求和 agent 抢同一个实例。** 实测过一个反例：客户端有个给动作生成中文描述的辅助请求（48 token 的小请求），服务器空闲时 0.5 秒返回，被 agent 的上千 token prefill 压住时 decode 掉到 0.2–0.6 tok/s、要 33 秒以上，三分之一直接超时失败。这类辅助功能要么走另一个实例，要么在本地单实例部署时关掉。

### 量化档位

推荐 **6-bit**。在同一批测试里，8-bit 和 6-bit 的输出质量与 bf16 统计上测不出差异（置信区间含 0），4-bit 起才出现显著回退，而 6-bit 在质量不可区分的档位里最快。

## 确认是否生效

看服务端日志 `Prefill completed` 那行的 `cached_tokens`。agent 连续对话到第二步之后，它应当明显大于 0。

如果一直是 0，按这个顺序排查：客户端的截图丢弃是否还是每步一张（最常见）；`MLX_INLINE_IMAGE_POSITIONS` 是否漏配；是否设了历史思考步数上限。另一个有用的信号是日志里的 `images=N`：它应当呈现「4→5→6→7→4」这样的锯齿起伏，如果恒定不变，说明客户端仍在每步丢弃一张。

## 一处默认行为变更

`server/request_normalization.py` 里修的是 vLLM 兼容性 bug：原版只认顶层的 `enable_thinking`，忽略 vLLM 客户端惯用的 `chat_template_kwargs.enable_thinking`，导致思考模式被静默丢弃。

这一处**没有开关、默认生效**。如果你的客户端此前依赖「该字段被忽略」的行为，升级后会发生变化。

## 改动清单

共 10 个文件，`+540 / −27` 行，以新增为主。

| 文件 | 作用 |
|---|---|
| `apc.py` | 前缀按图片边界对齐、逐图 hash |
| `generate/dispatch.py` | 单轮生成路径的前缀复用 |
| `generate/ar.py` | 连续批处理路径（服务端实际走这条） |
| `models/qwen3_5/language.py` | 复用前缀时保住 mRoPE 位置编码 |
| `models/qwen3_5/qwen3_5.py` | 逐图视觉编码与缓存 |
| `prompt_utils.py`、`server/openai.py` | 图片 token 按消息就位 |
| `server/generation.py` | 逐图 hash 透传 |
| `server/request_normalization.py` | `chat_template_kwargs` 兼容 |
| `vision_cache.py` | 逐图缓存开关 |

## 未验证项

如实列出，便于自行判断风险：

- **只在连续批处理路径上实测过。** 服务端走的是 `generate/ar.py`，收益数据全部来自这条路径。`generate/dispatch.py`（单轮生成）做了同步改动，但没有在服务场景下同等验证。
- **不依赖 monkey patch 这一点未实测。** 早期方案用过一个 `sitecustomize.py` 把 embeddings 从缓存盐值里摘掉（`APC_REUSE_ACROSS_PROMPTS=1`）。本补丁在 `ar.py` 里已直接处理，按代码路径分析该 patch 已冗余，所以上面的环境变量清单里没有它——但「去掉它收益依然成立」没有单独跑过对照。若你的命中率明显低于预期，可以把它作为排查方向之一。
- **只在 Qwen3.5 系列上验证过。** 其余 `qwen3_5` 架构的模型理论上适用，未实测。

## 回滚

```bash
./apply.sh --revert
```

也可以直接用 `apply.sh` 生成的 `mlx_vlm.before-gui-agent-cache.*.tar` 恢复，或者最省事的 `pip install --force-reinstall mlx-vlm==0.6.8`。

## 许可

上游 `mlx-vlm` 为 MIT（Copyright © 2025 Prince Canuma），原文见 `LICENSE.upstream`。本补丁为其修改内容，同样以 MIT 分发。
