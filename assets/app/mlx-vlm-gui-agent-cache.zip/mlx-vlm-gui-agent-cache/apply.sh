#!/usr/bin/env bash
# 把「GUI Agent 前缀缓存」补丁应用到已安装的 mlx-vlm。
#
# 用法：
#   ./apply.sh                     # 打到当前 python3 环境的 mlx-vlm 上
#   PYTHON=/path/to/venv/bin/python ./apply.sh
#   ./apply.sh --revert            # 回滚
#
# 脚本本身不改 python 环境之外的任何东西，应用前会自动备份。

set -euo pipefail

EXPECTED_VERSION="0.6.8"
PATCH_NAME="mlx-vlm-${EXPECTED_VERSION}-gui-agent-cache.patch"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$HERE/$PATCH_NAME"
PYTHON="${PYTHON:-python3}"
REVERT=0
[ "${1:-}" = "--revert" ] && REVERT=1

# 是否已打过补丁，用补丁引入的标识判断。
#
# 不用 `patch -R --dry-run` 来试探：macOS 自带的 patch(2.0-12u11-Apple) 在反向
# 不匹配时会交互式问 "Unreversed (or previously applied) patch detected! Ignore
# -R? [y]"，默认答案是 y，于是它转头去做正向应用并返回成功——原版会被误判
# 成"已应用"。所有 patch 调用都带 -t，就是为了不在这类提问上卡住。
SENTINEL="APC_GROWING_IMAGES"
SENTINEL_FILE="mlx_vlm/apc.py"

die() { echo "错误：$*" >&2; exit 1; }
is_applied() { grep -q "$SENTINEL" "$SENTINEL_FILE" 2>/dev/null; }

[ -f "$PATCH" ] || die "找不到补丁文件 $PATCH"
command -v patch >/dev/null || die "系统缺少 patch 命令"

# mlx_vlm 的父目录就是 site-packages，补丁里的路径以 mlx_vlm/ 开头，
# 所以 patch -p1 必须在这一层执行。
SITE_DIR="$("$PYTHON" -c 'import os,mlx_vlm;print(os.path.dirname(os.path.dirname(os.path.abspath(mlx_vlm.__file__))))' 2>/dev/null)" \
  || die "$PYTHON 里没装 mlx-vlm，先 pip install mlx-vlm==${EXPECTED_VERSION}"
VERSION="$("$PYTHON" -c 'import mlx_vlm;print(mlx_vlm.__version__)')"

echo "python : $PYTHON"
echo "目标   : $SITE_DIR/mlx_vlm"
echo "版本   : $VERSION"
echo

if [ "$VERSION" != "$EXPECTED_VERSION" ]; then
  # 版本不符时不硬拦，但必须让人知道 hunk 可能对不上。
  echo "注意：补丁是针对 ${EXPECTED_VERSION} 制作的，当前是 ${VERSION}。"
  echo "      下面的试运行如果报 hunk 失败，请改用 pip install mlx-vlm==${EXPECTED_VERSION}。"
  echo
fi

cd "$SITE_DIR"

if [ "$REVERT" = "1" ]; then
  is_applied || die "当前代码里没有本补丁的痕迹，拒绝回滚（如需恢复请用备份 tar）"
  patch -p1 -R -t --dry-run <"$PATCH" >/dev/null \
    || die "回滚试运行失败，未做任何修改（代码可能已被其它改动动过，请用备份 tar 恢复）"
  patch -p1 -R -t <"$PATCH"
  find mlx_vlm -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true
  echo
  echo "已回滚到上游原版。"
  exit 0
fi

if is_applied; then
  echo "补丁已经应用过，无需重复操作。"
  exit 0
fi

BACKUP="$SITE_DIR/mlx_vlm.before-gui-agent-cache.$(date +%Y%m%d-%H%M%S).tar"
tar -cf "$BACKUP" mlx_vlm
echo "已备份 : $BACKUP"
echo

echo "试运行……"
patch -p1 -t --dry-run <"$PATCH" || die "试运行失败，未做任何修改。请确认 mlx-vlm 版本为 ${EXPECTED_VERSION}"
echo
echo "应用……"
patch -p1 -t <"$PATCH"
is_applied || die "应用后未检测到补丁标识，请用备份恢复：$BACKUP"

# 不清掉旧的 .pyc，解释器可能继续加载补丁前的字节码。
find mlx_vlm -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true

cat <<'EOF'

完成。补丁的新特性默认全部关闭，需要下面这组环境变量才会生效：

  export APC_ENABLED=1
  export APC_GROWING_IMAGES=1               # 图片逐步增长时复用前缀
  export MLX_INLINE_IMAGE_POSITIONS=1       # 图片 token 按消息就位（前提）
  export MLX_VLM_PER_IMAGE_VISION_CACHE=1   # 逐图视觉特征缓存
  export MLX_VLM_VISION_CACHE_SIZE=20
  export APC_EXACT_CACHE_ENTRIES=8
  export APC_EXACT_PREFIX_GUARD_TOKENS=64

确认是否真的生效：看服务端日志里 Prefill completed 那行的 cached_tokens，
agent 连续对话到第二步之后应当明显大于 0。

回滚：./apply.sh --revert
EOF
